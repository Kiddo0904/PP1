from pathlib import Path
import time
import logging
import pyautogui
import os
import cv2
import numpy as np
from PIL import ImageGrab
from pywinauto import Desktop

# Intentar imports relativos (cuando se ejecuta como módulo)
# Si falla, usar imports absolutos (cuando se ejecuta directamente)
try:
    from .util_imagen import buscar_plantilla_pantalla, leer_configuracion_plantilla, _obtener_ruta_base
    from .cache_coordenadas import CacheCoordenadas
except ImportError:
    import sys
    sys.path.insert(0, str(Path(__file__).parent))
    from util_imagen import buscar_plantilla_pantalla, leer_configuracion_plantilla, _obtener_ruta_base
    from cache_coordenadas import CacheCoordenadas


class ControladorApp:
    """Controlador ligero de la aplicación SIRAT."""

    def __init__(self, logger: logging.Logger = None, img_dir: Path = None, cache_path: Path = None):
        self.logger = logger or logging.getLogger(__name__)
        project_root = _obtener_ruta_base()
        self.img_dir = Path(img_dir).resolve() if img_dir else project_root / "IMG"
        self.coords_cache = CacheCoordenadas(Path(cache_path).resolve() if cache_path else project_root / "coords_cache.json")

    def _resolver_busqueda_imagen(self, image_name: str, threshold_default: float = 0.70):
        """Resuelve escala y threshold para la imagen desde configuracion_corte.txt."""
        template_name = Path(image_name).name
        config_path = _obtener_ruta_base() / "configuracion_corte.txt"
        escala, threshold = leer_configuracion_plantilla(template_name, config_path, logger=self.logger)

        if escala is None or escala <= 0:
            escala = 1.0
        if threshold is None or threshold <= 0:
            threshold = threshold_default

        escalas = [float(escala)]
        if float(escala) < 1.0:
            escalas.append(1.0)
        if float(escala) != 0.95:
            escalas.append(0.95)
        if float(escala) != 0.90:
            escalas.append(0.90)
        if float(escala) != 0.85:
            escalas.append(0.85)

        # Eliminar duplicados preservando orden
        escalas = list(dict.fromkeys(escalas))

        self.logger.info(f"Búsqueda {image_name}: escala={escala}, threshold={threshold*100:.0f}%, fallback={escalas}")
        return float(escala), float(threshold), escalas

    def open_app(self, shortcut_path: Path = None) -> bool:
        """Intenta lanzar la aplicación si se proporciona shortcut_path, luego enfoca la ventana SIRAT.
        
        Si shortcut_path se proporciona:
        1. Ejecuta el atajo "Actualiza RSIRAT.lnk"
        2. Espera a que aparezca la ventana SIRAT
        
        Luego intenta enfocar la ventana SIRAT.
        Retorna True si pudo intentar (no garantiza login).
        """
        try:
            # Si se proporciona shortcut, intentar ejecutarlo
            if shortcut_path:
                if Path(shortcut_path).exists():
                    try:
                        self.logger.info(f"Ejecutando aplicación desde: {shortcut_path}")
                        os.startfile(str(shortcut_path))
                        time.sleep(2.0)  # Esperar a que se lance la app
                    except Exception as e:
                        self.logger.warning(f"No se pudo ejecutar shortcut: {e}")
                else:
                    self.logger.warning(f"Shortcut no encontrado: {shortcut_path}")
            
            # Intentar enfocar la ventana SIRAT
            desktop = Desktop(backend="uia")
            try:
                win = desktop.window(title_re=".*SIRAT.*")
                if win.exists(timeout=5):
                    try:
                        win.set_focus()
                    except Exception:
                        pass
                    time.sleep(0.5)
                    return True
            except Exception:
                pass
            try:
                desktop.active().set_focus()
                time.sleep(0.3)
            except Exception:
                pass
            return True
        except Exception as e:
            self.logger.error(f"Error en open_app: {e}")
            return False

    def click_image(self, image_name: str, clicks: int = 1, timeout: float = 10.0, poll: float = 0.3) -> bool:
        """Busca `image_name` en `self.img_dir` y hace clic en el centro si la encuentra."""
        try:
            tpl = Path(self.img_dir) / image_name
            escala, threshold, escalas = self._resolver_busqueda_imagen(image_name)
            encontrado = buscar_plantilla_pantalla(
                tpl,
                threshold=threshold,
                timeout=timeout,
                poll=poll,
                escala=escala,
                escalas=escalas,
            )
            if not encontrado:
                self.logger.warning(f"Imagen no encontrada: {tpl} con escala/threshold={escala}/{threshold}")
                return False
            x, y = encontrado
            for i in range(clicks):
                pyautogui.click(x, y)
                time.sleep(0.02)
            self.logger.info(f"Clic(s) en {image_name}: ({x},{y}) x{clicks}")
            return True
        except Exception as e:
            self.logger.error(f"Error click_image {image_name}: {e}")
            return False

    def click_image_and_type(self, image_name: str, text: str, timeout: float = 10.0, poll: float = 0.3) -> bool:
        ok = self.click_image(image_name, clicks=1, timeout=timeout, poll=poll)
        if not ok:
            return False
        time.sleep(0.3)
        self.type_preserve_zeros(text)
        return True

    def type_preserve_zeros(self, text: str):
        for c in str(text):
            pyautogui.typewrite(c, interval=0.02)
        time.sleep(0.2)

    def _leer_configuracion_roi(self):
        """Lee los valores de recorte ROI usados para la selección azul.

        Prioriza la configuración del paso actual (1p_...) sobre otras secciones del
        archivo y mantiene compatibilidad con las claves antiguas (roi_..., etc.).
        """
        config_path = _obtener_ruta_base() / "configuracion_corte.txt"
        porcentaje = 20
        min_px = 300
        margen_superior = 5
        margen_inferior = 10
        margen_izquierdo = 0
        ancho_base = 1920
        ancho_final = None

        try:
            if config_path.exists():
                primera_parte = {}
                generica = {}
                with open(config_path, "r", encoding="utf-8") as f:
                    for linea in f:
                        linea = linea.strip()
                        if not linea or linea.startswith("#") or "=" not in linea:
                            continue
                        clave, valor = [p.strip() for p in linea.split("=", 1)]

                        if clave.startswith("1p_"):
                            primera_parte[clave] = valor
                        elif clave in {"primera_parte_porcentaje", "primera_parte_min_px", "margen_superior",
                                       "margen_inferior", "margen_izquierdo", "ancho_pantalla_base",
                                       "ancho_captura_final", "roi_porcentaje", "roi_min_px",
                                       "roi_percent", "roi_minimo_px"}:
                            generica[clave] = valor

                # 1P tiene prioridad absoluta para la primera parte del expediente.
                if "1p_primera_parte_porcentaje" in primera_parte:
                    try:
                        porcentaje = int(float(primera_parte["1p_primera_parte_porcentaje"]))
                    except ValueError:
                        pass
                elif "primera_parte_porcentaje" in generica:
                    try:
                        porcentaje = int(float(generica["primera_parte_porcentaje"]))
                    except ValueError:
                        pass
                elif "roi_porcentaje" in generica or "roi_percent" in generica:
                    clave = "roi_porcentaje" if "roi_porcentaje" in generica else "roi_percent"
                    try:
                        porcentaje = int(float(generica[clave]))
                    except ValueError:
                        pass

                if "1p_primera_parte_min_px" in primera_parte:
                    try:
                        min_px = int(float(primera_parte["1p_primera_parte_min_px"]))
                    except ValueError:
                        pass
                elif "primera_parte_min_px" in generica:
                    try:
                        min_px = int(float(generica["primera_parte_min_px"]))
                    except ValueError:
                        pass
                elif "roi_min_px" in generica or "roi_minimo_px" in generica:
                    clave = "roi_min_px" if "roi_min_px" in generica else "roi_minimo_px"
                    try:
                        min_px = int(float(generica[clave]))
                    except ValueError:
                        pass

                if "1p_margen_superior" in primera_parte:
                    try:
                        margen_superior = int(float(primera_parte["1p_margen_superior"]))
                    except ValueError:
                        pass
                elif "margen_superior" in generica:
                    try:
                        margen_superior = int(float(generica["margen_superior"]))
                    except ValueError:
                        pass

                if "1p_margen_inferior" in primera_parte:
                    try:
                        margen_inferior = int(float(primera_parte["1p_margen_inferior"]))
                    except ValueError:
                        pass
                elif "margen_inferior" in generica:
                    try:
                        margen_inferior = int(float(generica["margen_inferior"]))
                    except ValueError:
                        pass

                if "1p_margen_izquierdo" in primera_parte:
                    try:
                        margen_izquierdo = int(float(primera_parte["1p_margen_izquierdo"]))
                    except ValueError:
                        pass
                elif "margen_izquierdo" in generica:
                    try:
                        margen_izquierdo = int(float(generica["margen_izquierdo"]))
                    except ValueError:
                        pass

                if "1p_ancho_pantalla_base" in primera_parte:
                    try:
                        ancho_base = int(float(primera_parte["1p_ancho_pantalla_base"]))
                        if ancho_base <= 0:
                            ancho_base = 1920
                    except ValueError:
                        pass
                elif "ancho_pantalla_base" in generica:
                    try:
                        ancho_base = int(float(generica["ancho_pantalla_base"]))
                        if ancho_base <= 0:
                            ancho_base = 1920
                    except ValueError:
                        pass

                if "1p_ancho_captura_final" in primera_parte:
                    try:
                        ancho_final = int(float(primera_parte["1p_ancho_captura_final"]))
                    except ValueError:
                        pass
                elif "ancho_captura_final" in generica:
                    try:
                        ancho_final = int(float(generica["ancho_captura_final"]))
                    except ValueError:
                        pass
        except Exception:
            pass

        return porcentaje, min_px, margen_superior, margen_inferior, margen_izquierdo, ancho_base, ancho_final

    def _detectar_region_azul(self, img_bgr):
        """Busca la región azul activa de la fila/expediente en la pantalla."""
        if img_bgr is None or img_bgr.size == 0:
            return None

        h, w = img_bgr.shape[:2]
        b = img_bgr[:, :, 0].astype(np.int16)
        g = img_bgr[:, :, 1].astype(np.int16)
        r = img_bgr[:, :, 2].astype(np.int16)

        mascara_azul = (r < 80) & (b > r + 120) & (b > g + 25)
        num_componentes, _, stats, _ = cv2.connectedComponentsWithStats(mascara_azul.astype(np.uint8), 8)

        candidatos = []
        for i in range(1, num_componentes):
            x, y, ancho, alto, area = stats[i]
            if ancho > 80 and alto > 8 and area > 300 and alto < 60 and (ancho / alto) > 5:
                candidatos.append((area, x, y, ancho, alto))

        if not candidatos:
            return None

        porcentaje, min_px, margen_superior, margen_inferior, margen_izquierdo, ancho_base, _ancho_final = self._leer_configuracion_roi()
        ancho_base_uso = ancho_base if ancho_base > 0 else max(1, w)
        ancho_esperado = max(min_px, int(ancho_base_uso * porcentaje / 100))
        ancho_esperado = min(ancho_esperado, max(1, w))

        # La selección activa suele estar en la parte izquierda/inicio de la fila, y
        # además debe guardar una proporción cercana a la configurada en configuracion_corte.txt.
        mejor_candidato = None
        mejor_score = None
        for area, x, y, ancho, alto in candidatos:
            # priorizar candidatos en la izquierda + que encajen con el ancho esperado
            x_cercano_izq = 0 if x <= w * 0.75 else 1
            ancho_diff = abs(ancho - ancho_esperado)
            anchura_relativa = abs((x + ancho) - w)
            score = (x_cercano_izq, ancho_diff / max(1, ancho_esperado), anchura_relativa / max(1, w), x)

            if mejor_score is None or score < mejor_score:
                mejor_score = score
                mejor_candidato = (area, x, y, ancho, alto)

        if mejor_candidato is None:
            return None

        _, x, y, ancho, alto = mejor_candidato
        x0 = max(0, x - 10)
        y0 = max(0, y - 5)
        x1 = min(w, x + ancho + 10)
        y1 = min(h, y + alto + 10)
        return (x0, y0, x1, y1)

    def _recortar_region_azul(self, img_bgr):
        """Recorta la zona azul/seleccionada usando la configuración del archivo de cortes."""
        coords = self._detectar_region_azul(img_bgr)
        if coords is None:
            self.logger.debug("No se detectó selección azul visible con el tamaño esperado; se evita capturar una zona arbitraria de la pantalla.")
            return None

        x0, y0, x1, y1 = coords
        porcentaje, min_px, margen_superior, margen_inferior, margen_izquierdo, ancho_base, ancho_final = self._leer_configuracion_roi()

        ancho_total = max(1, img_bgr.shape[1])
        ancho_esperado = max(min_px, int((ancho_base if ancho_base > 0 else ancho_total) * porcentaje / 100))
        if ancho_final is not None and ancho_final > 0:
            ancho_esperado = min(ancho_esperado, ancho_final)

        x_recorte_izq = max(0, x0 + margen_izquierdo)
        x_recorte_der = min(img_bgr.shape[1], x_recorte_izq + ancho_esperado)
        y0_ajustado = max(0, y0 + margen_superior)
        y1_ajustado = max(y0_ajustado + 1, y1 - margen_inferior)

        roi = img_bgr[y0_ajustado:y1_ajustado, x_recorte_izq:x_recorte_der]
        if roi.size == 0:
            self.logger.warning("La región azul detectada quedó vacía tras el recorte; se descarta la captura.")
            return None
        return roi

    def _esperar_region_azul(self, timeout_segundos: float = 10.0, poll_segundos: float = 0.05, lecturas_estables: int = 2):
        """Busca la selección azul justo después del TAB, con microbúsqueda.

        Captura la pantalla cada `poll_segundos` (50 ms por defecto) durante un máximo de
        `timeout_segundos` (10 s). Devuelve el ROI en cuanto lo detecta, pero exige
        `lecturas_estables` capturas consecutivas idénticas para no quedarse con la fila
        a medio pintar (azul ya visible pero texto aún sin dibujar).
        """
        inicio = time.time()
        fin = inicio + timeout_segundos
        roi_previo = None
        estables = 0
        ultimo_roi = None
        while time.time() < fin:
            try:
                img = np.array(ImageGrab.grab())
                img_bgr = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
                roi = self._recortar_region_azul(img_bgr)
                if roi is not None:
                    ultimo_roi = roi
                    if roi_previo is not None and roi.shape == roi_previo.shape and np.array_equal(roi, roi_previo):
                        estables += 1
                    else:
                        estables = 1
                    roi_previo = roi
                    if estables >= lecturas_estables:
                        self.logger.info(f"Selección azul detectada y estable en {time.time() - inicio:.2f}s")
                        return roi
                else:
                    roi_previo = None
                    estables = 0
            except Exception as e:
                self.logger.error(f"Error al detectar selección azul: {e}", exc_info=True)
            time.sleep(poll_segundos)

        # Timeout: si llegó a verse la fila azul aunque no se estabilizara, se usa la última lectura.
        if ultimo_roi is not None:
            self.logger.warning(f"Timeout de {timeout_segundos}s sin estabilizar la lectura; se usa la última selección azul detectada.")
            return ultimo_roi
        return None

    def extraer_seleccion_azul_expediente(self, debug_dir: Path, num_fila: int, timeout: float = 10.0, poll: float = 0.05):
        try:
            debug_path = Path(debug_dir)
            debug_path.mkdir(parents=True, exist_ok=True)

            roi = self._esperar_region_azul(timeout_segundos=timeout, poll_segundos=poll)
            if roi is not None:
                destino = debug_path / f"fila_{num_fila}_expediente.png"
                ok = cv2.imwrite(str(destino), roi)
                if ok:
                    self.logger.info(f"Selección azul guardada (ROI): {destino}")
                    return destino
                self.logger.warning(f"No se pudo guardar la selección azul en {destino}")
                return None

            self.logger.warning(f"No se detectó selección azul visible en {timeout}s para fila {num_fila}; se omite la captura.")
            return None
        except Exception as e:
            self.logger.error(f"Error en extraer_seleccion_azul_expediente: {e}")
            return None

    def obtener_coordenada_seleccion_azul(self):
        """Devuelve la coordenada Y (borde superior) de la fila azul visible, o None si no hay.

        Sirve para saber si tras presionar DOWN la selección se movió: si la coordenada se
        repite, la selección no avanzó y ya no hay más filas por recorrer.
        """
        try:
            img = np.array(ImageGrab.grab())
            img_bgr = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            coords = self._detectar_region_azul(img_bgr)
            return None if coords is None else int(coords[1])
        except Exception as e:
            self.logger.error(f"Error al obtener la coordenada de la selección azul: {e}", exc_info=True)
            return None

    def comparar_selecciones_azules(self, img1_path: str | Path, debug_dir: Path = None, num_fila_temp: int = None) -> float:
        """Compara la referencia azul guardada con la región azul actual de la pantalla."""
        try:
            # Leer referencia en color (canal azul será usado)
            ref_color = cv2.imread(str(img1_path), cv2.IMREAD_COLOR)
            if ref_color is None:
                return 0.0

            img_actual = np.array(ImageGrab.grab())
            img_actual_bgr = cv2.cvtColor(img_actual, cv2.COLOR_RGB2BGR)
            roi_actual = self._recortar_region_azul(img_actual_bgr)
            if roi_actual is None:
                self.logger.warning("No hay selección azul visible para comparar; se devuelve similitud 0.0.")
                return 0.0

            # Redimensionar referencia a ROI actual
            h_roi, w_roi = roi_actual.shape[:2]
            if h_roi == 0 or w_roi == 0:
                return 0.0
            referencia_color = cv2.resize(ref_color, (w_roi, h_roi))

            # Comparación directa sin filtrado: usar la imagen color tal cual se guardó.
            try:
                res = cv2.matchTemplate(roi_actual, referencia_color, cv2.TM_CCOEFF_NORMED)
                _, max_val, _, _ = cv2.minMaxLoc(res)
                similitud = float(max_val)
            except Exception as e:
                self.logger.error(f"Error en matchTemplate directo: {e}")
                similitud = 0.0

            self.logger.info(f"Comparación — similitud={similitud:.4f}")

            if debug_dir is not None and num_fila_temp is not None:
                debug_dir = Path(debug_dir)
                debug_dir.mkdir(parents=True, exist_ok=True)
                try:
                    cv2.imwrite(str(debug_dir / f"comparacion_{num_fila_temp}_actual.png"), roi_actual)
                    cv2.imwrite(str(debug_dir / f"comparacion_{num_fila_temp}_ref.png"), referencia_color)
                except Exception:
                    pass

            return similitud
        except Exception as e:
            self.logger.error(f"Error en comparar_selecciones_azules: {e}")
            return 0.0

    # Alias para compatibilidad con el código actual
    capturar_seleccion_azul = extraer_seleccion_azul_expediente
    calcular_similitud_selecciones_azules = comparar_selecciones_azules

    def detect_expediente_invalido(self, timeout: float = 2.0) -> bool:
        """
        Detecta si hay un mensaje de error de expediente inválido en la ventana SIRAT.
        
        Busca palabras clave:
        - "expediente inválido"
        - "expediente no válido"
        - "no existe"
        - "error"
        
        Retorna True si detecta error, False si no.
        """
        try:
            self.logger.info("Verificando si hay mensaje de expediente inválido...")
            desktop = Desktop(backend="uia")
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    win = desktop.window(title_re=".*SIRAT.*")
                    if win.exists(timeout=1):
                        for desc in win.descendants():
                            try:
                                txt = desc.window_text() or ""
                                if txt.strip():
                                    txt_lower = txt.lower()
                                    palabras_clave = [
                                        "expediente inválido",
                                        "expediente no válido",
                                        "no existe",
                                        "error"
                                    ]
                                    if any(palabra in txt_lower for palabra in palabras_clave):
                                        self.logger.error(f"Mensaje de expediente inválido detectado: {txt}")
                                        return True
                            except Exception:
                                continue
                except Exception:
                    pass
                time.sleep(0.25)
            
            return False
        except Exception as e:
            self.logger.error(f"Error en detect_expediente_invalido: {e}")
            return False

    def login(self, dependencia: str, password: str = "") -> bool:
        """Login: escribe dependencia, TAB, contraseña y ENTER.

        Detecta mensajes de error de contraseña incorrecta.
        Retorna True si login OK, False si login falló o error de contraseña.
        """
        try:
            desktop = Desktop(backend="uia")
            try:
                win = desktop.window(title_re=".*SIRAT.*")
                if not win.exists(timeout=5):
                    self.logger.warning("Ventana SIRAT no encontrada para login")
                    return False
                try:
                    win.set_focus()
                except Exception:
                    pass
            except Exception:
                try:
                    desktop.active().set_focus()
                except Exception:
                    pass

            time.sleep(0.5)
            self.logger.info(f"Digitando dependencia: {dependencia}")
            self.type_preserve_zeros(str(dependencia))
            time.sleep(0.1)
            pyautogui.press('tab')
            time.sleep(0.2)
            self.logger.info("Digitando contraseña...")
            self.type_preserve_zeros(str(password))
            time.sleep(0.1)
            pyautogui.press('return')
            time.sleep(0.5)

            if self.detect_password_error(timeout=1.5):
                self.logger.error("Contraseña incorrecta detectada. Login falló.")
                return False

            self.logger.info("Login completado exitosamente")
            return True
        except Exception as e:
            self.logger.error(f"Error en login: {e}")
            return False

    def detect_password_error(self, timeout: float = 2.0) -> bool:
        """Detecta si hay un mensaje de error de contraseña en la ventana SIRAT."""
        try:
            self.logger.info("Verificando si hay mensaje de error de contraseña...")
            desktop = Desktop(backend="uia")
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    win = desktop.window(title_re=".*SIRAT.*")
                    if win.exists(timeout=1):
                        for desc in win.descendants():
                            try:
                                txt = desc.window_text() or ""
                                if txt.strip():
                                    txt_lower = txt.lower()
                                    palabras_clave = [
                                        "no puede ser accedido",
                                        "estimado usuario",
                                        "error en las credenciales",
                                        "error numero",
                                        "credenciales"
                                    ]
                                    if any(palabra in txt_lower for palabra in palabras_clave):
                                        self.logger.error(f"Mensaje de error detectado: {txt}")
                                        return True
                            except Exception:
                                continue
                except Exception:
                    pass
                time.sleep(0.25)
            return False
        except Exception as e:
            self.logger.error(f"Error en detect_password_error: {e}")
            return False


__all__ = ["ControladorApp"]
