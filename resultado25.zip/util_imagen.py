from pathlib import Path
import time
import sys
import os
import cv2
import numpy as np
from PIL import ImageGrab


def _obtener_ruta_base():
    """Obtiene la ruta base del proyecto.
    
    Usa sys.argv[0] (más robusto para script y ejecutable).
    Fallback a sys.executable si sys.argv[0] no es confiable.
    
    Nota: Los archivos deben estar en la MISMA carpeta que el ejecutable/script.
    """
    try:
        # sys.argv[0] funciona tanto en script como en ejecutable
        ruta = os.path.dirname(os.path.abspath(sys.argv[0]))
        if ruta:
            return Path(ruta)
    except Exception:
        pass
    
    # Fallback: usar sys.executable (ejecutable)
    try:
        if getattr(sys, 'frozen', False):
            return Path(sys.executable).resolve().parent
    except Exception:
        pass
    
    # Último fallback: __file__
    return Path(__file__).resolve().parent


def _normalizar_threshold(valor):
    """Convierte 75 a 0.75 y deja 0.75 como 0.75."""
    try:
        valor_num = float(valor)
        if valor_num <= 1.0:
            return valor_num
        return valor_num / 100.0
    except (TypeError, ValueError):
        return 0.75


def leer_configuracion_plantilla(template_name: str, config_path: Path = None, logger=None):
    """Lee escala y threshold desde configuracion_corte.txt.

    Ejemplo esperado:
      img_002_escala=0.95
      img_002_threshold=75
      escala_default=0.95
      threshold_default=70
    """
    if config_path is None:
        config_path = _obtener_ruta_base() / "configuracion_corte.txt"

    nombre_archivo = Path(template_name).stem
    clave_escala = f"img_{nombre_archivo}_escala"
    clave_threshold = f"img_{nombre_archivo}_threshold"

    escala_default = 0.95
    threshold_default = 0.70
    escala_encontrada = None
    threshold_encontrado = None
    config_exists = config_path.exists()

    if config_exists:
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                for linea in f:
                    linea = linea.strip()
                    if not linea or linea.startswith("#") or "=" not in linea:
                        continue
                    clave, valor = [p.strip() for p in linea.split("=", 1)]
                    if clave in {"escala_default", "default_scale"}:
                        try:
                            escala_default = float(valor)
                        except ValueError:
                            pass
                    elif clave in {"threshold_default", "default_threshold"}:
                        try:
                            threshold_default = _normalizar_threshold(valor)
                        except ValueError:
                            pass
                    elif clave == clave_escala:
                        try:
                            escala_encontrada = float(valor)
                        except ValueError:
                            pass
                    elif clave == clave_threshold:
                        try:
                            threshold_encontrado = _normalizar_threshold(valor)
                        except ValueError:
                            pass
        except Exception as e:
            if logger:
                logger.warning(f"Error al leer {config_path}: {e}")

    escala_final = escala_encontrada if escala_encontrada is not None else escala_default
    threshold_final = threshold_encontrado if threshold_encontrado is not None else threshold_default

    if logger:
        if config_exists:
            if escala_encontrada is not None or threshold_encontrado is not None:
                logger.info(f"  Config {nombre_archivo}: escala={escala_final} (esp.), threshold={threshold_final*100:.0f}% (esp.)")
            else:
                logger.info(f"  Config {nombre_archivo}: escala={escala_final} (def.), threshold={threshold_final*100:.0f}% (def.)")
        else:
            logger.warning(f"  Config NO ENCONTRADA en {config_path}, usando defaults")

    return escala_final, threshold_final


def buscar_plantilla_pantalla(
    template_path: Path,
    threshold: float = 0.85,
    timeout: float = 10.0,
    poll: float = 0.3,
    escala: float = None,
    escalas: list = None,
):
    """Busca una plantilla en pantalla, soportando escala configurada y fallback entre varias escalas."""
    template_path = Path(template_path)
    if not template_path.exists():
        return None

    if escalas is None:
        if escala is not None:
            escalas = [float(escala)]
        else:
            escalas = [1.0]

    escalas = [float(e) for e in escalas if e is not None]
    if not escalas:
        escalas = [1.0]

    threshold = _normalizar_threshold(threshold)

    template = cv2.imread(str(template_path), cv2.IMREAD_GRAYSCALE)
    if template is None:
        return None

    end_time = time.time() + timeout
    while time.time() < end_time:
        try:
            img = np.array(ImageGrab.grab())
            screen = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            screen_gray = cv2.cvtColor(screen, cv2.COLOR_BGR2GRAY)

            for escala_actual in escalas:
                if escala_actual <= 0:
                    continue

                nuevo_ancho = max(1, int(template.shape[1] * escala_actual))
                nuevo_alto = max(1, int(template.shape[0] * escala_actual))
                template_redimensionado = cv2.resize(
                    template,
                    (nuevo_ancho, nuevo_alto),
                    interpolation=cv2.INTER_AREA,
                )

                res = cv2.matchTemplate(screen_gray, template_redimensionado, cv2.TM_CCOEFF_NORMED)
                min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)

                if max_val >= threshold:
                    top_left = max_loc
                    center_x = int(top_left[0] + nuevo_ancho / 2)
                    center_y = int(top_left[1] + nuevo_alto / 2)
                    return center_x, center_y

        except Exception:
            pass

        time.sleep(poll)

    return None


__all__ = ["buscar_plantilla_pantalla", "leer_configuracion_plantilla", "_obtener_ruta_base"]
